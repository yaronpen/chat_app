module.exports = {
  env: {
    browser: true,
    es2021: false,
    node: false
  },
  extends: [
    'standard'
  ],
  parserOptions: {
    ecmaVersion: 12
  },
  rules: {
  }
}
